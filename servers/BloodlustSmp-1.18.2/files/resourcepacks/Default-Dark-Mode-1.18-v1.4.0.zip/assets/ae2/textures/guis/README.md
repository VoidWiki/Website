# AE2Things
Neat little additions to AE2: Fabric

This mod adds two machines from AE2Stuff the Advanced Inscriber and Crystal Growth Chamber, and a new type of cell the DISK: Deep Item Storage disK. This cell has no type limits and one item counts as one byte. Due to limitations with the cell format, you lose 24 bytes per kibibyte, but hey a small price to pay for no types right?
